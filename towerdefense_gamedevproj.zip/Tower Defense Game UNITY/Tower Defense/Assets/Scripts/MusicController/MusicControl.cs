﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MusicControl : MonoBehaviour {

    public Slider BGM_slider, SFX_slider;
    


	void Start () {
		
	}
	
	void Update () {
		
	}
}
